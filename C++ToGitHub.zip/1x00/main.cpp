/*  File:   main.cpp
 * Author: sean
 * Read 'till you don't understand. Then write it 'till you do. 
 
 * Created on September 24, 2017, 9:10 AM
 */
#include <iostream>  
#include <string>  
#include <vector> 
#include "dataMin" 

using std::cout;
using std::endl;
using std::string;
using std::cin;
using std::vector;

int main() 
{
    //use the getDat class to gather basic information
    getDat data1;
    //get the age of the current user
    cout << "[*] Please Enter Your Age: ";
    cin >> data1.age;
    //get the name of the current user.
    cout << "[*] Your Name: ";
    cin >> data1.name;

    cout << "[*] Now Enter In Your Address : ";
    //get the address of the current user
    //used a for loop to limit the scope of the variable.
    for (string dat; cin >> dat;) {
        //store an address in the vector
        data1.address.push_back(dat);
    }
    //present the information gathered by the program.
    cout << "Hello I am " << data1.name << " and I am " << data1.age
            << " Years old. " << "I live at: ";
    for (auto &x : data1.address) {
        //cout << x[x] << " ";
        cout << x << " ";
    }
    cout << endl;
    return 0;
}
